export interface TrainTicket {
  id: string;
  trainNumber: string;
  fromStation: string;
  toStation: string;
  departureTime: string;
  arrivalTime: string;
  duration: string;
  price: number;
  seatsAvailable: {
    business: number;
    first: number;
    second: number;
    standing: number;
  };
  type: 'G' | 'D' | 'K' | 'Z'; // G-HighSpeed, D-Electric, K-Fast, Z-Direct
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
  isThinking?: boolean;
}

export interface Station {
  code: string;
  name: string;
  city: string;
}

export enum AppView {
  HOME = 'HOME',
  SEARCH_RESULTS = 'SEARCH_RESULTS',
}

export interface SearchParams {
  from: string;
  to: string;
  date: string;
  onlyHighSpeed: boolean;
}
