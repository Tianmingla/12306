import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";

let chatSession: Chat | null = null;

const getAIClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.error("API_KEY is missing");
    return null;
  }
  return new GoogleGenAI({ apiKey });
};

export const initializeChat = async () => {
  const ai = getAIClient();
  if (!ai) return null;

  try {
    chatSession = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: `You are 'RailBot', a helpful and polite customer service assistant for RailConnect (a platform similar to 12306). 
        Your goal is to help users with railway travel questions in China.
        
        Key Capabilities:
        1. Explain ticket policies (refunds, changes, student tickets).
        2. Suggest travel itineraries or popular destinations.
        3. Provide estimated travel times between major cities (e.g., Beijing to Shanghai is approx 4.5 hours on G-train).
        4. Be concise and friendly. Use emojis occasionally.
        
        If asked about real-time specific seat availability, explain that you are a demo assistant and cannot access live inventory database yet.`,
        temperature: 0.7,
      },
    });
    return chatSession;
  } catch (error) {
    console.error("Failed to initialize chat", error);
    return null;
  }
};

export const sendMessageToGemini = async (message: string): Promise<string> => {
  if (!chatSession) {
    await initializeChat();
  }

  if (!chatSession) {
    return "I'm sorry, I cannot connect to the service right now. Please check your API key.";
  }

  try {
    const response: GenerateContentResponse = await chatSession.sendMessage({ message });
    return response.text || "I didn't catch that. Could you please repeat?";
  } catch (error) {
    console.error("Error sending message to Gemini:", error);
    return "Sorry, I encountered an error processing your request.";
  }
};
