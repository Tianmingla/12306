import React, { useState } from 'react';
import Navbar from './components/Navbar';
import SearchWidget from './components/SearchWidget';
import TrainList from './components/TrainList';
import Features from './components/Features';
import AIAssistant from './components/AIAssistant';
import { AppView, SearchParams } from './types';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<AppView>(AppView.HOME);
  const [searchParams, setSearchParams] = useState<SearchParams | null>(null);

  const handleSearch = (params: SearchParams) => {
    setSearchParams(params);
    setCurrentView(AppView.SEARCH_RESULTS);
  };

  const handleNavigate = (view: AppView) => {
    setCurrentView(view);
  };

  return (
    <div className="min-h-screen bg-gray-50 font-sans text-gray-900 pb-20">
      <Navbar onNavigate={handleNavigate} />

      {currentView === AppView.HOME && (
        <>
          {/* Hero Section */}
          <div className="relative h-[500px] w-full bg-slate-900 overflow-hidden">
            <img 
              src="https://picsum.photos/1920/600?grayscale" 
              alt="Train Station" 
              className="absolute inset-0 w-full h-full object-cover opacity-60 mix-blend-overlay"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-blue-900/90 to-blue-600/40"></div>
            <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex flex-col justify-center pb-24">
              <h1 className="text-4xl md:text-6xl font-extrabold text-white mb-4 tracking-tight">
                Your Journey <br/>
                <span className="text-blue-300">Starts Here</span>
              </h1>
              <p className="text-xl text-blue-100 max-w-xl">
                Experience seamless railway travel across China. High-speed, comfortable, and always on time.
              </p>
            </div>
          </div>
          
          <SearchWidget onSearch={handleSearch} />
          <Features />
        </>
      )}

      {currentView === AppView.SEARCH_RESULTS && searchParams && (
        <div className="animate-fade-in">
          <TrainList 
            searchParams={searchParams} 
            onBack={() => setCurrentView(AppView.HOME)} 
          />
        </div>
      )}

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 py-12 mt-auto">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-gray-400 text-sm">© 2024 RailConnect Service Platform. All rights reserved.</p>
        </div>
      </footer>

      <AIAssistant />
    </div>
  );
};

export default App;
