import React, { useState, useEffect } from 'react';
import { Clock, ChevronRight, Filter } from 'lucide-react';
import { TrainTicket, SearchParams } from '../types';

interface TrainListProps {
  searchParams: SearchParams;
  onBack: () => void;
}

const TrainList: React.FC<TrainListProps> = ({ searchParams, onBack }) => {
  const [tickets, setTickets] = useState<TrainTicket[]>([]);
  const [loading, setLoading] = useState(true);

  // Simulate API fetch
  useEffect(() => {
    setLoading(true);
    setTimeout(() => {
      const mockData: TrainTicket[] = Array.from({ length: 8 }).map((_, i) => {
        const hour = 7 + i;
        const durationH = 4 + Math.floor(Math.random() * 2);
        const durationM = Math.floor(Math.random() * 60);
        
        return {
          id: `train-${i}`,
          trainNumber: `${searchParams.onlyHighSpeed ? 'G' : ['G','D','Z'][Math.floor(Math.random()*3)]}${1000 + i}`,
          fromStation: searchParams.from,
          toStation: searchParams.to,
          departureTime: `${hour.toString().padStart(2, '0')}:${Math.floor(Math.random() * 60).toString().padStart(2, '0')}`,
          arrivalTime: `${(hour + durationH).toString().padStart(2, '0')}:${Math.floor(Math.random() * 60).toString().padStart(2, '0')}`,
          duration: `${durationH}h ${durationM}m`,
          price: 553 + Math.floor(Math.random() * 100),
          seatsAvailable: {
            business: Math.floor(Math.random() * 5),
            first: Math.floor(Math.random() * 20),
            second: Math.floor(Math.random() * 100),
            standing: 0
          },
          type: 'G'
        };
      });
      setTickets(mockData);
      setLoading(false);
    }, 800);
  }, [searchParams]);

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-4">
          <button onClick={onBack} className="text-gray-500 hover:text-blue-600 font-medium">
            ← Back
          </button>
          <div>
            <h2 className="text-2xl font-bold text-gray-800">
              {searchParams.from} <span className="text-gray-400 mx-2">to</span> {searchParams.to}
            </h2>
            <p className="text-gray-500 text-sm">{searchParams.date}</p>
          </div>
        </div>
        <div className="flex space-x-2">
          <button className="flex items-center px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm font-medium hover:bg-gray-50">
            <Filter className="h-4 w-4 mr-2" /> Filter
          </button>
        </div>
      </div>

      {/* Date Tabs */}
      <div className="flex space-x-2 mb-6 overflow-x-auto pb-2">
        {[-1, 0, 1, 2, 3].map(offset => {
          const d = new Date(searchParams.date);
          d.setDate(d.getDate() + offset);
          const isSelected = offset === 0;
          return (
            <button 
              key={offset}
              className={`flex-shrink-0 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                isSelected 
                  ? 'bg-blue-600 text-white shadow-md' 
                  : 'bg-white text-gray-600 hover:bg-gray-50 border border-gray-200'
              }`}
            >
              {d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
            </button>
          );
        })}
      </div>

      {/* List */}
      <div className="space-y-4">
        {loading ? (
          // Skeletons
          Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 animate-pulse h-32"></div>
          ))
        ) : (
          tickets.map((ticket) => (
            <div key={ticket.id} className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 hover:shadow-md transition-shadow group">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                
                {/* Time & Station */}
                <div className="flex items-center gap-8 min-w-[280px]">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-900">{ticket.departureTime}</div>
                    <div className="text-sm font-medium text-gray-600">{ticket.fromStation}</div>
                  </div>
                  
                  <div className="flex flex-col items-center justify-center min-w-[100px]">
                    <span className="text-xs text-gray-400">{ticket.trainNumber}</span>
                    <div className="w-full h-[2px] bg-gray-200 relative my-1">
                      <div className="absolute right-0 -top-1 w-2 h-2 border-t-2 border-r-2 border-gray-200 rotate-45"></div>
                    </div>
                    <div className="flex items-center text-xs text-gray-400">
                      <Clock className="h-3 w-3 mr-1" />
                      {ticket.duration}
                    </div>
                  </div>

                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-900">{ticket.arrivalTime}</div>
                    <div className="text-sm font-medium text-gray-600">{ticket.toStation}</div>
                  </div>
                </div>

                {/* Seats */}
                <div className="flex-1 flex flex-wrap gap-x-6 gap-y-2 text-sm text-gray-500">
                  <div className="flex items-baseline">
                    <span className="mr-2">2nd Class</span>
                    <span className={`font-semibold ${ticket.seatsAvailable.second > 0 ? 'text-green-600' : 'text-gray-400'}`}>
                      {ticket.seatsAvailable.second > 0 ? 'Available' : 'Sold Out'}
                    </span>
                  </div>
                  <div className="flex items-baseline">
                    <span className="mr-2">1st Class</span>
                    <span className={`font-semibold ${ticket.seatsAvailable.first > 0 ? 'text-green-600' : 'text-gray-400'}`}>
                      {ticket.seatsAvailable.first > 10 ? 'Available' : ticket.seatsAvailable.first}
                    </span>
                  </div>
                   <div className="flex items-baseline">
                    <span className="mr-2">Business</span>
                    <span className={`font-semibold ${ticket.seatsAvailable.business > 0 ? 'text-green-600' : 'text-gray-400'}`}>
                      {ticket.seatsAvailable.business}
                    </span>
                  </div>
                </div>

                {/* Price & Action */}
                <div className="flex items-center justify-between md:flex-col md:items-end gap-2 md:min-w-[120px]">
                  <div className="text-right">
                    <span className="text-xs text-gray-400 align-top">¥</span>
                    <span className="text-3xl font-bold text-blue-600">{ticket.price}</span>
                  </div>
                  <button className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors shadow-sm flex items-center">
                    Book <ChevronRight className="h-4 w-4 ml-1" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default TrainList;
